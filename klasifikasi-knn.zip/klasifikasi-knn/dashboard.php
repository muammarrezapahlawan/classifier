<?php  include('header.php')?>
<div class="main-content">
  <div class="container-fluid">

    <div class="row">
      <div class="col-md-12">
        <div class="card mb-4">
          <div class="card-header">
            Selamat datang user :
          </div>
          <div class="card-body">
            Sistem ini digunakan untuk
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php  include('footer.php')?>