<?php  include('header.php')?>
<div class="main-content">
  <div class="container-fluid">

    <div class="row">
      <div class="col-md-12">
        <div class="card mb-4">
          <div class="card-header">
            Perhitungan
          </div>
          <div class="card-body">

            <!DOCTYPE html>
            <html lang="en">

            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>Bootstrap 5 Form</title>
              <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            </head>

            <body>
              <div class="container mt-1">

                <form action="proses.php" method="POST">
                  <div class="mb-3">

                    <input type="text" class="form-control" id="nama" placeholder="Masukan Nama Ibu" name="nama">
                  </div>
                  <div class="mb-3">

                    <input type="text" class="form-control" id="namabalita" placeholder="masukan Nama balita"
                      name="namaB">
                  </div>

                  <div class="mb-3">

                    <input type="text" class="form-control" id="umurbalita" placeholder="Masukan umur Balita" name="x">
                  </div>

                  <div class="mb-3">

                    <input type="text" class="form-control" id="beratbalita" placeholder="Masukan Berat Balita"
                      name="y">
                  </div>

                  <button type="submit" class="btn btn-danger">Proses</button>
                </form>
              </div>
              <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js">
              </script>
            </body>

            </html>


          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php  include('footer.php')?>